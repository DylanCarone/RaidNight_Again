﻿using UnityEngine;
public class BuffEffect : StatusEffect
{
    private BuffType buffType;
    private float amount;
    private float currentShieldAmount; // for shield buffs
    
    public BuffType BuffType => buffType;
    public float Amount => amount;

    public void Initialize(CombatEntity caster, CombatEntity target, string name, float duration,
        BuffType buffType, float buffAmount, GameObject effectPrefab)
    {
        
        this.buffType = buffType;
        this.amount = buffAmount;
        this.visualEffectPrefab = effectPrefab;
        this.duration = duration;
        
        if(buffType == BuffType.Shield)
            currentShieldAmount = amount;
        
        base.Initialize(caster, target, name, duration);
    }

    protected override void OnApplied()
    {
        ApplyBuff();
    }

    protected override void OnRefresh()
    {
        if (buffType == BuffType.Shield)
        {
            currentShieldAmount = amount;
        }
    }

    protected override void OnTick()
    {
        if (buffType == BuffType.ResourceRegeneration && target is PlayerCombatEntity player)
        {
            player.RestoreResource(amount);
            Debug.Log($"{effectName} restores {amount} resource to {player.name}");
        }
    }

    protected override void OnExpired()
    {
        RemoveBuff();
    }

    protected override void OnRemoved()
    {
        RemoveBuff();
    }

    protected override float GetTickRate()
    {
        if (buffType == BuffType.ResourceRegeneration)
            return 1f;
        
        // most buffs dont tick
        return float.MaxValue;
    }

    private void ApplyBuff()
    {
        if (target == null) return;

        switch (buffType)
        {
            case BuffType.DamageReduction:
                target.SetDamageReduction(amount);
                break;
        }
    }
    
    private void RemoveBuff()
    {
        if (target == null) return;

        switch (buffType)
        {
            case BuffType.DamageReduction:
                target.ResetDamageReduction();
                break;
        }
    }

    /// <summary>
    /// Absorb damage with shield (called from TakeDamage)
    /// </summary>
    public float AbsorbDamage(float incomingDamage)
    {
        if (buffType != BuffType.Shield) return incomingDamage;
        if (currentShieldAmount >= incomingDamage)
        {
            currentShieldAmount -= incomingDamage;
            return 0f;
        }
        else
        {
            float remainingDamage = incomingDamage - currentShieldAmount;
            currentShieldAmount = 0f;
            RemoveEffect();
            return remainingDamage;
        }
    }
}
